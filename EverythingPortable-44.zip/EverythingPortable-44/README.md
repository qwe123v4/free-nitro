# EverythingPortable

[![Twitter URL](https://img.shields.io/twitter/url/https/twitter.com/fold_left.svg?style=social&label=Follow%20%40MARlOMASTA64)](https://twitter.com/MARlOMASTA64)

# this project has been revived

**i finally started working on the project again after many years and everything works again aside whats notes in the issues below**

# also issues are to be reported here:

**https://github.com/MarioMasta64/EverythingPortable/issues/14**

# updates:

allows downloading binaries from my repositories (all things ive released)

allows removing binaries

all binaries can coexist in harmony

all binaries are now easier to use

binaries now have options to download needed .dll files (specificly for obs portable and cemu portable)

now includes downloader option in all my other projects

option to write quicklaunchers

suite can now update launchers ! (any old launchers must be updated manually first as the old launchers dont have "hooks" to the new suites updater)

# Known Issues:

many of the launchers had a broken update process (goto Update-Now should've been goto UpdateNow)
this has been fixed and is easily updateable anyways simply type "UpdateNow" at the menu

# Rules of Kindness:

you may modify this without permission for your own personal use but if you wish to edit it i would appreciate if you ran it by me first (and dont do like some people have done where they simply take my entire launcher replace the "you may edit this for your own personal use only" credits with your own handle and put it in a gist, that is just sad.)

permission to request: making wrappers or guis for the launcher (many projects such as slimapps and portableapps and such already do what my project does and way better i would suggest using them instead if you want a gui without issues theyre likely made better as well), making edits to add functions (request it and more than likely id be willing to add it myself)

# Personal Notes:

ill update this as needed. but seriously if you want a gui just use a different project thats not what this is made for. this is simply for "its bare minimum i can do it quickly i dont have to think that hard (except for when i do; exa: epic games portable) and moreso a prototype just to use for myself than anyone else, so if you want quality and not something that has bugs everywhere i suggest you look elsewhere, sure it may work but the fact that everything is done live means it could break alot in the future and what works now likely wont work later, theres a reason people make repacks when making portables instead of doing it live and this is why, its just a silly project.

TL;DR dont take the project seriously if its good for you great but its primarily made with my needs in mind. if you want something better i reccommond searching up your favorite program and adding ".paf.exe" to it
